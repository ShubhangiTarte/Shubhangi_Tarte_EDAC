use assg5;
delimiter $$
create procedure cur1()
begin
declare finished int default 0;
declare name1 varchar(20) ;
declare sal1 int(20) ;
declare cursor1 cursor for select ename,sal from emp where job="ANALYST";
declare continue handler for not found set finished=1;
open cursor1;
loop1:loop 
fetch cursor1 into name1,sal1;
if finished=1 then
  leave loop1;
end if;
-- update emp set sal=sal1+100 where ename=name1 ;
select name1, sal1 ;
end loop loop1;
close cursor1;
end $$
call cur1();
drop procedure cur1;
select * from emp;
select emane 
end$$

delimiter $$
create procedure cur_p1()
begin
declare finished int default 0;
declare name1 varchar(20) ;
declare sal1 int(20) ;
declare cursor1 cursor for select ename,sal from emp;
declare continue handler for not found set finished=1;
open cursor1;
loop1:loop 
fetch cursor1 into name1,sal1;
if finished=1 then
  leave loop1;
end if;
update emp set sal=sal1+100 where ename=name1 ;

end loop loop1;
close cursor1;
end $$
call cur_p1();
drop procedure cur1;
select * from emp;


delimiter $$
create procedure cur2()
begin
declare finished int default 0;
declare no1 int;
declare name1 varchar(20);
declare sal1 int; 
declare cursor2 cursor for select empno,ename,sal from emp order by sal  desc limit 5 ; 
declare continue handler for not found set finished=1;
open cursor2;
loop1:loop
fetch cursor2 into no1,name1,sal1;
if (finished=1)then
 leave loop1;
 end if;
select no1,name1,sal1; 

end loop loop1;
close cursor2;
end$$

call cur2();

delimiter $$
create procedure cur4()
begin
declare finished int default 0;
declare name1 varchar(20);
declare no1 int;
declare job1 varchar(20);
declare manager1 int;
declare hiredate1 date;
declare sal1 int;
declare deptno1 int;

declare cursor4 cursor for select ename, empno, job, mgr,hiredate,sal, deptno from emp where ename="Manish";
declare continue handler for not found set finished=1;
open cursor4;
loop1:loop
fetch cursor4 into name1,no1,job1,manager1,hiredate1,sal1,deptno1 ;
if(finished=1) then
leave loop1;
end if;
select name1,no1,job1,manager1,hiredate1,sal1,deptno1;
end loop loop1;
close cursor4;

end$$
call cur4();
drop procedure cur4;
alter table emp add column lastname varchar(30);
update emp set lastname="Patil";


delimiter $$
create procedure cur3()
begin
declare finished int default 0;
declare name1 varchar(20);
declare lastname1 varchar(30);
-- declare cursor3 cursor for select concat( ename,lastname)as fullname from emp;
declare cursor3 cursor for select ename ,lastname from emp;

declare continue handler for not found set finished=1;
open cursor3;
loop1:loop
fetch cursor3 into name1,lastname1;
if(finished=1) then
leave loop1;
end if;
select concat(name1, " ",lastname1) as fullname;
end loop loop1;
close cursor3;
end $$

call cur3();
drop procedure cur3;
select * from emp;

delimiter $$
create procedure cur3_1()
begin
declare finished int default 0;
declare name1 varchar(20);
declare lastname1 varchar(30);
-- declare cursor3 cursor for select concat( ename,lastname)as fullname from emp;
declare cursor3_1 cursor for select ename ,lastname from emp;

declare exit handler for not found set finished=1;
open cursor3_1;
loop1:loop
fetch cursor3_1 into name1,lastname1;
if(finished=1) then
leave loop1;
end if;
select concat(name1, " ",lastname1) as fullname;
end loop loop1;
close cursor3_1;
end $$

call cur3_1();



delimiter $$
create procedure cur5()
begin
declare finished int default 0;
declare name1 varchar(20);
declare no1 int;
declare job1 varchar(20);
declare manager1 int;
declare hiredate1 date;
declare sal1 int;
declare deptno1 int;

declare cursor5 cursor for select ename, empno, job, mgr,hiredate,sal, deptno from emp where sal >1000;
declare continue handler for sqlexception set finished=1;
open cursor5;
loop1:loop
fetch cursor5 into name1,no1,job1,manager1,hiredate1,sal1,deptno1 ;
if(finished=1) then
leave loop1;
end if;
-- delete from name1,no1,job1,manager1,hiredate1,sal1,deptno1;
delete from emp;
end loop loop1;
close cursor5;

end$$
call cur5();
drop procedure cur5;
create table emp as select * from emp;
drop table emp;