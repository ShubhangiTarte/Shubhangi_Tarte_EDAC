use assg2;
show tables;

create table publishers(pubid int(5) primary key,
pname varchar(20),
email varchar(20) unique,
phone varchar(30));
alter table publishers modify pubid int(3);
desc publishers;

create table subjects(
subid varchar(20) primary key,
sname varchar(30));
alter table subjects modify subid varchar(5);
set foreign_key_checks=0;
set foreign_key_checks=1;
desc subjects;
create table authors(
auid int(5) primary key,
aname varchar(30),
email varchar(50) unique,
phone varchar(30));
desc authors;
CREATE TABLE  TITLES
(
    TITLEID    int(5) PRIMARY KEY,
    TITLE      VARCHAR(30),
    PUBID      int(3),
    SUBID      VARCHAR(5),
    PUBDATE    DATE,
    COVER      CHAR(1)   CHECK ( COVER IN ('P','H','p','h')),
    PRICE      int(4),
	CONSTRAINT TITLES_PUBID_FK FOREIGN KEY (PUBID) REFERENCES PUBLISHERS(PUBID),
	CONSTRAINT TITLES_SUBID_FK FOREIGN KEY (SUBID) REFERENCES SUBJECTS(SUBID));
    CREATE TABLE  TITLEAUTHORS
(
    TITLEID    int(5) ,
    AUID       int(5) ,
    IMPORTANCE int(2),
   PRIMARY KEY(TITLEID,AUID),
   CONSTRAINT  TITLESAUTHORS_TITLEID_FK FOREIGN KEY (TITLEID) REFERENCES TITLES(TITLEID),
   CONSTRAINT  TITLESAUTHORS_AUTHID_FK FOREIGN KEY (AUID) REFERENCES AUTHORS(AUID)
);
CREATE TABLE  SUBJECTS_BACKUP
(
    SUBID      VARCHAR(5) PRIMARY KEY,
    SNAME      VARCHAR(30));
    INSERT INTO SUBJECTS VALUES ('ORA','ORACLE DATABASE 10g');
 INSERT INTO SUBJECTS VALUES ('JAVA','JAVA LANGUAGE');
 INSERT INTO SUBJECTS VALUES ('JEE','JAVA ENTEPRISE EDITION');
 INSERT INTO SUBJECTS VALUES ('VB','VISUAL BASIC.NET');
 INSERT INTO SUBJECTS VALUES ('ASP','ASP.NET');

INSERT INTO PUBLISHERS VALUES (1,'WILLEY','WDT@VSNL.NET','91-11-23260877');
 INSERT INTO PUBLISHERS VALUES (2,'WROX','INFO@WROX.COM',NULL);
INSERT INTO PUBLISHERS VALUES (3,'TATA MCGRAW-HILL','FEEDBACK@TA.COM','91-11-33333322');
INSERT INTO PUBLISHERS VALUES (4,'TECHMEDIA','BOOKS@TECHMEDIA.COM','91-11-33257660');

 INSERT INTO AUTHORS VALUES (101, 'HERBERT SCHILD','HERBERT@YAHOO.COM',NULL);
 INSERT INTO AUTHORS VALUES (102, 'JAMES GOODWILL','GOODWILL@HOTMAIL.COM',NULL);
INSERT INTO AUTHORS VALUES (103, 'DAVAID HUNTER','HUNTER@HOTMAIL.COM',NULL);
INSERT INTO AUTHORS VALUES (104, 'STEPHEN WALTHER','WALTHER@GMAIL.COM',NULL);
INSERT INTO AUTHORS VALUES (105, 'KEVIN LONEY','LONEY@ORACLE.COM',NULL);
INSERT INTO AUTHORS VALUES (106, 'ED. ROMANS','ROMANS@THESERVERSIDE.COM',NULL);
select * from publishers;
select * from SUBJECTS;
select * from AUTHORS;
select * from TITLES;
select * from TITLEAUTHORS;
INSERT INTO TITLES VALUES (1001,'ASP.NET UNLEASHED',4,'ASP','02-04-12','P',540);
INSERT INTO TITLES VALUES (1002,'ORACLE10G COMP. REF.',3,'ORA','05-05-01','P',575);
INSERT INTO TITLES VALUES (1003,'MASTERING EJB',1,'JEE','05-02-03','P',475);
INSERT INTO TITLES VALUES (1004,'JAVA COMP. REF',3,'JAVA','05-04-03','P',499);
INSERT INTO TITLES VALUES (1005,'PRO. VB.NET',2,'VB','05-06-15','P',450);
update titles set pubdate='02-4-12' where titleid=1001;
update titles set pubdate='05-5-1' where titleid=1002;
update titles set pubdate='05-02-03' where titleid=1003;
update titles set pubdate='05-04-03' where titleid=1004;
update titles set pubdate='05-06-15' where titleid=1005;
 insert into publishers values(5,'abc','abc@gmai.com',23456789);
 
INSERT INTO TITLEAUTHORS VALUES (1001,104,1);
INSERT INTO TITLEAUTHORS VALUES (1002,105,1);
INSERT INTO TITLEAUTHORS VALUES (1003,106,1);
INSERT INTO TITLEAUTHORS VALUES (1004,101,1);
INSERT INTO TITLEAUTHORS VALUES (1005,103,1);
INSERT INTO TITLEAUTHORS VALUES (1005,102,2);

select pname,phone,email from publishers;
select aname, phone from authors;
select titleid,title ,pubdate from titles;
select auid,titleid,importance from titleauthors;

-- Ques 2)
select sname from subjects where sname like 'oracle%';
select sname from subjects where sname like'j%';
select sname from subjects where sname like'%.net';
select aname from authors where aname like'%er';
select pname from publishers where pname like '%hill%';

-- Ques 3)
desc titles;
select title from titles where price<500;
select title from titles where pubdate>'00-04-03';

