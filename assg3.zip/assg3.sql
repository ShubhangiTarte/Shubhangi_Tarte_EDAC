use assg3;
desc department;
desc  employee;
select * from department;
select * from employee;
insert into department(dept_id,dept_name) values(1,"abc");
delete from department;
create table Employee(
empid int(10),
emp_name varchar(30),
dept_id int,
 FOREIGN KEY (dept_id)REFERENCES department(dept_id),
salary int(10),
manager varchar(20));
desc employee;
insert into department(dept_id,dept_name) values(1,"Finance");
insert into department values(2,"Training");
insert into department values(3,"Marketing");
insert into department values(1,'Finance');

insert into employee(empid,emp_name,dept_id,salary,manager) values(1,'Arun',1,8000,4);
insert into employee(empid,emp_name,dept_id,salary,manager) values(2,'kiran',1,7000,1);
insert into employee(empid,emp_name,dept_id,salary,manager) values(3,'scott',1,3000,1);
insert into employee(empid,emp_name,dept_id,salary) values(4,'Max',2,9000);
insert into employee(empid,emp_name,dept_id,salary,manager) values(5,'Jack',2,8000,4);
insert into employee(empid,emp_name,salary,manager) values(6,'King',6000,1);