create database assg5;
use assg5;
Create table EMP ( EMPNO int(4) not null, 
ENAME varchar(30) not null, 
JOB varchar(10), 
MGR int(4),
 HIREDATE date, 
 SAL int(10), 
 DEPTNO int(2) ); 
 Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DeptNO ) values(1000,  'Manish' , 'SALESMAN', 1003,  '2020-02-18', 600,  30) ;
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DeptNO ) values(1001,  'Manoj' , 'SALESMAN', 1003,  '2018-02-18', 600,  30) ;
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DeptNO ) values(1002 , 'Ashish', 'SALESMAN',1003 , '2013-02-18',  750,  30 );
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DeptNO) values(1004,  'Rekha', 'ANALYST', 1006 , '2001-02-18', 3000,  10);
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DeptNO) values(1005 , 'Sachin', 'ANALYST', 1006 ,  '2019-02-18', 3000, 10 );
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DeptNO) values(1006,  'Pooja',  'MANAGER'  ,     null    , '2000-02-18' ,6000, 10 );


Create table dept (dno int(4) not null, dname varchar(10) not null,area varchar(30));
Insert into dept(dno,dname,area) values(10,'Store','Mumbai');
Insert into dept(dno,dname,area) values(20,'Purchase','Mumbai');
Insert into dept(dno,dname,area) values(30,'Store', 'Delhi');
Insert into dept(dno,dname,area) values(40,'Marketing','Pune');
Insert into dept(dno,dname,area) values(50,'Finance','Delhi');
Insert into dept(dno,dname,area) values(60,'Accounts','Mumbai');




delimiter $$
create procedure Ques1(in var1 int ,in var2 int)
begin
select var1+ var2;
select var1- var2;
select var1* var2;
select var1/var2;
select var1;
end $$
call Ques1(10,10);
delimiter $$
create procedure Q1()
begin
declare var varchar(10);
select ename from emp;
end $$
call Q1();
drop procedure Q1;
delimiter $$
create procedure Ques1_3(in var1 int ,in var2 int)
begin
declare v int;
-- set v=var1;
select var1 ;
select var1+ var2;
select var1- var2;
select var1* var2;
select var1/var2;
end $$
set var1=10;
set @var3=10;
call Ques1_3(@var1,@var3);
call Ques1_3(10,10);

drop procedure Ques1_3;


delimiter $$
-- create procedure Ques2(inout str varchar(10))
create procedure Ques2_22(in str varchar(10))
begin 
-- set str=(select reverse(str));
select reverse(str);
end$$
set @str='database';
call Ques2_22(@str);
select @str as reverse;


delimiter $$
create procedure Ques2_2(in str varchar(10))
begin 
select reverse(str);
-- select str as reverse;
end$$
 set @str='database';
call Ques2_2(@str);



delimiter $$
create procedure Ques3()
begin
select empno, ename,sal from emp order by sal desc limit 5;
end $$
call Ques3;

delimiter $$
create procedure Ques4()
begin
create table emp_test(e_id int(5),ename varchar(20),
e_joining_date date);
end $$
call Ques4
call Ques4();

delimiter $$
create procedure Ques5()
begin
insert into dept values(60,'Education','pune');
end$$
call Ques5();

delimiter $$
create procedure Ques5_1(in var1 int,in var2 varchar(10),in var3 varchar(10))
begin
insert into dept values (var1,var2,var3);
end $$
set @var1='60';
set @var2='Education';
set @var3='pune';
call Ques5_1(@var1, @var2,@var3);
select * from dept;





delimiter $$
 create procedure Ques6(inout num int, out sqr int,out cubee int)
 begin
 declare num2 int;
 set num2=num;
 select @num, power(@num,2),power(@num,3) into  num, sqr,cubee;
 end$$
 set @num=2;
 call Ques6(@num,@sqr,@cubee);
 select @num,@sqr,@cubee;
 
 drop procedure Ques6;
 
 
 
 delimiter $$
CREATE PROCEDURE Ques_7(OUT var INT)
BEGIN
DECLARE num int;
SET num=11;
SELECT num INTO var ;
END $$

CALL Ques_7(@var);
SELECT @var;

delimiter $$
create procedure Ques_8(in var1 int,  out var2 int )
begin

 